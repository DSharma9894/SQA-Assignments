﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using TriangleSolver;

namespace Test
{
    public class TriangleTest
    {
        [TestFixture]

        public class Triangle_test
        {
            [Test]
            public void AnalyzeTriangle_valid__Equilateral_Triangle()
            {
                int angle1 = 98;
                int angle2 = 98;
                int angle3 = 98;

                string expected = "Based on all sides being equal, the type of triangle is an EQUILATERAL";

                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }

            [Test]
            public void AnalyzeTriangle_valid_Isosceles_Triangle_1()
            {

                int angle1 = 70;
                int angle2 = 70;
                int angle3 = 26;

                string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";

                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);
            }

            [Test]
            public void AnalyzeTriangle_valid_Isosceles_Triangle_2()
            {

                int angle1 = 57;
                int angle2 = 60;
                int angle3 = 57;

                string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);
            }

            [Test]
            public void AnalyzeTriangle_valid_Isosceles_Triangle__3()
            {
                int angle1 = 30;
                int angle2 = 40;
                int angle3 = 40;

                string expected = "Based on two sides being equal, the type of triangle is an ISOSCELES";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }


            [Test]
            public void AnalyzeTriangle_valid_Scalene_Triangle_1()
            {
                int angle1 = 25;
                int angle2 = 24;
                int angle3 = 23;

                string expected = "Based on all three sides being different, the type of triangle is a SCALENE";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);
            }

            [Test]
            public void AnalyzeTriangle_valid_Scalene_Triangle_2()
            {
                int angle1 = 95;
                int angle2 = 37;
                int angle3 = 78;

                string expected = "Based on all three sides being different, the type of triangle is a SCALENE";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }

            [Test]
            public void AnalyzeTriangle_valid_Scalene_Triangle_3()
            {
                int angle1 = 80;
                int angle2 =106;
                int angle3 = 42;

                string expected = "Based on all three sides being different, the type of triangle is a SCALENE";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }

            [Test]
            public void AnalyzeTriangle_valid_Scalene_Triangle_4()
            {
                int angle1 = 60;
                int angle2 = 20;
                int angle3 = 76;

                string expected = "Based on all three sides being different, the type of triangle is a SCALENE";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }

            [Test]
            public void AnalyzeTriangle_valid_Scalene_Triangle_5()
            {
                int angle1 = 37;
                int angle2 = 60;
                int angle3 = 87;
                string expected = "Based on all three sides being different, the type of triangle is a SCALENE";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }

            [Test]
            public void AnalyzeTriangle_Zero_val_Triangle_1()
            {
                int angle1 = 48;
                int angle2 = 65;
                int angle3 = 0;

                string expected = "At least one side of your triangle has a zero length and is thus invalid";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }

            [Test]
            public void AnalyzeTriangle_Zero_val_Triangle_2()
            {
                int angle1 = 22;
                int angle2 = 0;
                int angle3 = 49;

                string expected = "At least one side of your triangle has a zero length and is thus invalid";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }


            [Test]
            public void AnalyzeTriangle_Zero_val_Triangle_3()
            {
                int angle1 = 0;
                int angle2 = 48;
                int angle3 = 38;

                string expected = "At least one side of your triangle has a zero length and is thus invalid";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }


            [Test]
            public void AnalyzeTriangle_inAnalyzeTriangle_valid_Triangle_1()
            {
                int angle1 = 100;
                int angle2 = 20;
                int angle3 = 73;

                string expected = "Based on the values entered, the triangle is INVALID";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }

            [Test]
            public void AnalyzeTriangle_inAnalyzeTriangle_valid_Triangle_2()
            {

                int angle1 = 31;
                int angle2 = 90;
                int angle3 = 20;

                string expected = "Based on the values entered, the triangle is INVALID";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }

            [Test]
            public void AnalyzeTriangle_inAnalyzeTriangle_valid_Triangle_3()
            {

                int angle1 = 1;
                int angle2 = 2;
                int angle3 = 3;

                string expected = "Based on the values entered, the triangle is INVALID";
                Triangle triangle = new Triangle();

                string actual = triangle.AnalyzeTriangle(angle1, angle2, angle3);

                Assert.AreEqual(expected, actual);

            }


        }


    }
}
